<?php

include '../includes/connection.php';
 if($_SESSION['mode']!='trainer')
 {
    header('location:../index.php');
 }
$i=1;
$id=$_SESSION['id'];
$sql = "SELECT * FROM `video` WHERE `member_id`=$id ";
$result = $conn->query($sql);


    // output data of each row

      ?>


<!DOCTYPE html>
<html lang="en">

<head>
  
    <title>Chazzen Fitness</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>

<?php

include 'includes/header.php';
?>   
          <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-12">
                        <h4 class="page-title">Student Approvel Request</h4>
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Student Applied for approvel</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>

                                        <tr>
                                            <th>#</th>
                                            <th>Video Title</th>
                                            <th>description</th>
                                            
                                           
                                            <!-- <th>Action</th> -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($result->num_rows > 0) {
                                            while($row = $result->fetch_assoc()) {
                                        echo "<tr>";
                                        echo "<td>{$i}</td>";
                                        echo "<td>{$row['video_title']}</td>";
                                        echo "<td>".substr($row['video_description'], 0, 40)."</td>";
                                       
                                        // echo "<td><button class='btn btn-success' onclick='approvel({$row['id']})'>Approve</button>
                                        // <button class='btn btn-danger' onclick='reject({$row['id']})'>Reject</button>
                                        // </td>";
                                        echo "</tr>";

    }
}else{
    echo "<tr><td><b>0 result</b></td><tr>";
} 
?>  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.container-fluid -->
        </div>
        <!-- /#page-wrapper -->
        <footer class="footer text-center" style="bottom: 0px"> 2021 &copy; Chazzen Fitness <a
                href="https://www.chazzenfitness.com/">chazzenfitness.com</a> </footer>
    </div>


    <!-- /#wrapper -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
  
    <!-- jQuery -->
   
    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!--Nice scroll JavaScript -->
    <script src="js/jquery.nicescroll.js"></script>
    <!--Morris JavaScript -->
    <script src="bower_components/raphael/raphael-min.js"></script>
    <script src="bower_components/morrisjs/morris.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/myadmin.js"></script>
    <script src="js/dashboard1.js"></script>
</body>

</html>