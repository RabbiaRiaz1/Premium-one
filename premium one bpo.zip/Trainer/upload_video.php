<?php
include '../includes/connection.php';
 if($_SESSION['mode']!='trainer')
 {
    header('location:../index.php');
 }
$filter=$body_focus="";
$member_id=$_SESSION['id'];
if (isset($_POST['submit'])) {
  $fileTmpPath = $_FILES['uploadedFile']['tmp_name'];
    $fileName = $_FILES['uploadedFile']['name'];
    $fileSize = $_FILES['uploadedFile']['size'];
    $fileType = $_FILES['uploadedFile']['type'];
    $fileNameCmps = explode(".", $fileName);
    $fileExtension = strtolower(end($fileNameCmps));
    $newFileName = md5(time() . $fileName) . '.' . $fileExtension;
    $allowedfileExtensions = array('jpg', 'gif', 'png', 'zip', 'txt', 'xls', 'doc');
    if (in_array($fileExtension, $allowedfileExtensions))
    {
      $uploadFileDir = 'uploads/';
      $dest_path = $uploadFileDir . $newFileName;
 
      if(move_uploaded_file($fileTmpPath, $dest_path)) 
      {
        $message ='File is successfully uploaded.';
      }
      else
      {
        $message = 'There was some error moving the file to upload directory. Please make sure the upload directory is writable by web server.';
      }
    }
    else
    {
      $message = 'Upload failed. Allowed file types: ' . implode(',', $allowedfileExtensions);
    }




$Equipment = $_POST['Equipment'];
if(is_array($Equipment))
{
foreach ($Equipment as $value) {
 $filter=$value.",".$filter;
}
}
$Training = $_POST['Training'];
if(is_array($Training))
{
foreach ($Training as $value) {
 $filter=$filter.",".$value;
}
}
$Training = $_POST['Training'];
if(is_array($Training))
{
foreach ($Training as $value) {
 $filter=$filter.",".$value;
}
}
$body = $_POST['body'];
if(is_array($body))
{
foreach ($body as $value) {
 $body_focus=$body_focus.$value;
}
}






$video_name=$_POST['video_name'];
$video_link=$_POST['video_link'];
$video_title=$_POST['video_title'];
$Description=$_POST['Description'];
$Calorie=$_POST['Calorie'];
$difficulty_level=$_POST['level'];


$sql = "INSERT INTO `video`( `video_title`, `video_name`, `video_description`, `Filter`, `member_id`, `Calorie`, `body_focus`, `difficulty_level`,`video_link`,`thumbnail`) VALUES ('$video_title','$video_name','$Description','$filter','$member_id','$Calorie','$body_focus','$difficulty_level','$video_link','$newFileName')";

if ($conn->query($sql) === TRUE) {
  $_SESSION['success']="Video added successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
  exit();
}
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  
    <title>Chazzen Fitness</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet">
     <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>

<![endif]-->

<script>
function _(el){
    return document.getElementById(el);
}
function uploadFile(){
    if(document.getElementById('file1').value=='')
    {
        exit;
    }
   
    document.getElementById('video_link').style.display="none";
    document.getElementById('video_link').required=false;
    document.getElementById('uploadbtn').disabled=true;
    document.getElementById('vid_success').style.display='block';

    document.getElementById('video_caption').style.display="none";
    document.getElementById('progressBar').style.display="block";
    var file = _("file1").files[0];
    // alert(file.name+" | "+file.size+" | "+file.type);
    var formdata = new FormData();
    formdata.append("file1", file);
    var ajax = new XMLHttpRequest();
    ajax.upload.addEventListener("progress", progressHandler, false);
    ajax.addEventListener("load", completeHandler, false);
    ajax.addEventListener("error", errorHandler, false);
    ajax.addEventListener("abort", abortHandler, false);
    ajax.open("POST", "file_upload_parser.php");
    ajax.send(formdata);
}
function progressHandler(event){
    _("loaded_n_total").innerHTML = parseInt(event.loaded/1000000)  +" / "+ parseInt(event.total/1000000);
    var percent = (event.loaded / event.total) * 100;
    _("progressBar").value = Math.round(percent);
    _("status").innerHTML = Math.round(percent);
}
function completeHandler(event){
    document.getElementById('uploadbtn').disabled=false;
    document.getElementById('vid_success').style.display='none';

    _("status").innerHTML = event.target.responseText;
    document.getElementById('video_name').value= event.target.responseText;

}
function errorHandler(event){
    _("status").innerHTML = "Upload Failed";
}
function abortHandler(event){
    _("status").innerHTML = "Upload Aborted";
}
</script>
</head>

<body>
    <!-- Preloader -->
   <?php

include 'includes/header.php';
?>   
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-12">
                        <h4 class="page-title">Welcome to chazzen Fitness</h4>
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                  <div class="container-fluid">
          
            <!-- row -->
            <div class="row">
                <div class="col-md-8 col-xs-12">
                    <div class="white-box">
                        <?php
                        if (isset($_SESSION['success'])) {
                           echo "<h1 class='text-center bg-success text-light'>".$_SESSION['success']."</h1>";
                           unset($_SESSION['success']);
                        }
                        ?>
                            <form  id="upload_form" class="form-horizontal form-material" enctype="multipart/form-data" method="post">
                            <div class="form-group">
                                <label class="col-md-12">Upload Video</label>
                                <div class="col-md-12">
                                    <input type="file"  class="form-control form-control-line"  accept="video/*" name="file1" id="file1"> 
                                    <progress id="progressBar" value="0" max="100" style="width:300px;display: none;" class="progress-bar mt_10"></progress><br> <h4 id="status" style="font-weight: bolder;display: inline-block;color: lightgreen"></h4><span></span>
                                      <span id="loaded_n_total" style="float: right;color: lightgreen"></span>
                                    <input type="button"  value="Upload File" onclick="uploadFile()" style="margin-top: 10px; padding: 10px 10px; background: #13dafe; color: white; border: 0px; border-radius: 5px;display: block;">
  
 

                                </div>
                            </div>

                        </form>
                        
                                      
                    </div>
                            <form method="post" enctype="multipart/form-data">
                            <div class="form-group">
                                <h3 class="text-center"><b>OR Enter Video link</b></h3>
                                <label class="col-md-12" id="video_caption">Video Link</label>
                                <div class="col-md-12">
                                      <input type="link" placeholder="Enter video link"
                                        class="form-control form-control-line" name="video_link" style="background: transparent;"   id="video_link" required="">

                                   


                                         </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12" >Video title</label>
                                <div class="col-md-12">
                                      <input type="text" placeholder="Enter video title"
                                        class="form-control form-control-line" name="video_title" style="background: transparent;" id="video_title" required="">

                                   


                                         </div>
                            </div>
                           
                            <div class="form-group" >
                                <label class="col-md-12" style="margin-top: 10px">Video Description</label>
                                <div class="col-md-12">
                                    <textarea rows="5" class="form-control form-control-line" name="Description" style="background: transparent;" placeholder="Enter Description of the video" required=""  hidden=""  id="summernote"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-md-12" style="margin-top: 10px">Calorie Burn</label>
                                <div class="col-md-12">
                                    <input type="text" placeholder="18-30"
                                        class="form-control form-control-line" name="Calorie" style="background: transparent;"> </div>
                            </div>
                            <div class="form-group" class="margin-top:10px">
                                <label class="col-md-12" style="margin-top: 10px">Equipment</label>
                                <div class="col-md-12">
                              
                                   
                                           <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="No equipment">
                                           <label style="margin-left: 10px">No Equipment</label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Dumbbell" ><label style="margin-left: 10px">Dumbbell</label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Mat"><label style="margin-left: 10px">Mat </label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Bench"><label style="margin-left: 10px">Bench</label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Exercise Band"><label style="margin-left: 10px">Exercise Band</label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Jump Rope"><label style="margin-left: 10px">Jump Rope</label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Kettlebell"><label style="margin-left: 10px">Kettlebell</label>
                                           <input type="checkbox" style="margin-left: 10px" name="Equipment[]" value="Medicine Ball"><label style="margin-left: 10px">Medicine Ball </label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Physio-Ball"><label style="margin-left: 10px">Physio-Ball </label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Equipment[]" value="Sandbag"><label style="margin-left: 10px" >Sandbag</label>
                                     

                               </div>
                            </div>
                             <div class="form-group">
                                <label class="col-md-12" style="margin-top: 10px">Training Type</label>
                                <div class="col-md-12">
                              
                                   
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="HIIT" ><label style="margin-left: 10px">HIIT</label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Strength Training"><label style="margin-left: 10px">Strength Training</label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Pilates"><label style="margin-left: 10px">Pilates  </label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Cardiovascular"><label style="margin-left: 10px">Cardiovascular </label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Stretching/Flexibility"><label style="margin-left: 10px">Stretching / Flexibility </label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="low Impact"><label style="margin-left: 10px">Low Impact</label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Warm up / Cool Down"><label style="margin-left: 10px">Warm Up / Cool Down</label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Kettlebell"><label style="margin-left: 10px">Kettlebell  </label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Toning"><label style="margin-left: 10px">Toning  </label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Balance / Agility"><label style="margin-left: 10px">Balance / Agility</label>
                                           <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Polyometric"><label style="margin-left: 10px">Plyometric  </label>
                                            <input type="checkbox"  style="margin-left: 10px" name="Training[]" value="Barre"><label style="margin-left: 10px">Barre   </label>
                                          

                               </div>
                            </div>
                              <div class="form-group">
                                <label class="col-md-12" style="margin-top: 10px">Body Focus</label>
                                <div class="col-md-12">
                              
                                   
                                           <input type="checkbox" name="body[]" value="upper" style="margin-left: 10px"><label style="margin-left: 10px">Upper</label>
                                           <input type="checkbox" name="body[]" value="Core" style="margin-left: 10px"><label style="margin-left: 10px">Core</label>
                                            <input type="checkbox" name="body[]" value="Lower" style="margin-left: 10px"><label style="margin-left: 10px">Lower  </label>
                                          
                                          

                               </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-12" style="margin-top: 10px"> Difficulty Level</label>
                                <div class="col-sm-12">
                                    <select class="form-control form-control-line" name="level">
                                        <option value="1">1</option>
                                        <option value="2">2</option>
                                        <option value="3">3</option>
                                        <option value="4">4</option>
                                        <option value="5">5</option>
                                    </select>
                                </div>
                            </div>
                               <div class="form-group ">
                                <label class="col-md-12"  style="margin-top: 20px !important" >Video Thumbnail here</label>
                                <div class="col-md-12">
                                      <input type="file" placeholder="Enter video title"
                                        class="form-control form-control-line" name="uploadedFile" style="background: transparent;" accept="image/*" required="">

                                   


                                         </div>
                            </div>
                             <input type="text" name="video_name" id="video_name" hidden="">
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <h2 style="color: red;display: none;" id="vid_success">Please wait for video to be uploaded completely</h2>
                                    <button class="btn btn-success" id="uploadbtn" type="submit" name="submit"style="    margin: 25px 0px 30px 2px;">Upload Video</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

                </div>
        <!-- /#page-wrapper -->
        <footer class="footer text-center" style="bottom: 0px"> 2021 &copy; Chazzen Fitness <a
                href="https://www.chazzenfitness.com/">chazzenfitness.com</a> </footer>
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
     <script type="text/javascript" src="js/fileupload.js"></script>
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

      <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>
       <script>
    $(document).ready(function() {
        $('#summernote').summernote();
    });
 var noteeditable =document.getElementByClassName('note-editable');
 alert(noteeditable.innerHTML)
  </script>
   

    <!-- Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!--Nice scroll JavaScript -->
    <script src="js/jquery.nicescroll.js"></script>
    <!--Morris JavaScript -->
    <script src="bower_components/raphael/raphael-min.js"></script>
    <script src="bower_components/morrisjs/morris.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/myadmin.js"></script>
    <script src="js/dashboard1.js"></script>
</body>

</html>