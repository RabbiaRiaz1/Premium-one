<?php
$id=$_POST['id'];
include "../../includes/connection.php";
$sql ="SELECT * FROM `video` WHERE `id` ='$id';";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$videoname= $row['video_name'];
$sql="DELETE FROM `video` WHERE `id` ='$id';";
$result=mysqli_query($conn,$sql);
if ($result) {
	if($videoname!="")
	{
	unlink("../videos/{$videoname}");
	
	}
	echo "Successfully delete video";
}
else{
	echo "There went something wrong";
}

?>