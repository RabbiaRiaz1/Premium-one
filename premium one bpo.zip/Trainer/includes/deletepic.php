<?php
$id=$_POST['id'];
include "../../includes/connection.php";
$sql ="SELECT * FROM `trainer_picture` WHERE `id` ='$id';";
$result=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($result);
$img= $row['image'];

$sql="DELETE FROM `trainer_picture` WHERE `id` ='$id';";
$result=mysqli_query($conn,$sql);
if ($result) {
	unlink("../images/{$img}");
	echo "Successfull";
}
else{
	echo "There went something wrong";
}

?>