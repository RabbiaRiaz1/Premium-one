<?php

include '../../includes/connection.php';
$i=1;
$id = $_POST['app_id'];
$sql = "UPDATE `approvel_request` SET `approved`='1' WHERE `id`='$id'";
if ($conn->query($sql) === TRUE) {  
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}


?>