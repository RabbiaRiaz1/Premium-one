<?php

include '../../includes/connection.php';
$i=1;
$id = $_POST['app_id'];
$sql = "DELETE FROM `approvel_request` WHERE  `id`='$id'";

if ($conn->query($sql) === TRUE) {
  echo "Record updated successfully";
} else {
  echo "Error updating record: " . $conn->error;
}


?>