<?php

include '../includes/connection.php';
$unique_id=$_SESSION['unique_id'];
 if($_SESSION['mode']!='trainer')
 {
    header('location:../index.php');
 }
 if(!isset($_SESSION['id']))
 {
    $email=$_SESSION['email'];
 $sql="SELECT * FROM `trainers` WHERE `email` = '$email'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc()) {
    $_SESSION['id']=$row['id'];
  }}else{
        header('location:../index.php');
  }

}
$id=$_SESSION['id'];
$sql = "SELECT * FROM `video` WHERE `member_id`=$id ";
$result = $conn->query($sql);
$videos=  mysqli_num_rows($result);
$unique_id=$_SESSION['unique_id'];
$sql = "SELECT * FROM `approvel_request` WHERE `teacher_id`='$unique_id'  and `approved`= '0'";
$result = $conn->query($sql);
$request=  mysqli_num_rows($result);

$sql = "SELECT * FROM `approvel_request` WHERE `teacher_id`='$unique_id'  and `approved`= '1'";
$result = $conn->query($sql);
$student=  mysqli_num_rows($result);
$sql = "SELECT * FROM `trainers` WHERE `unique_id`='$unique_id'  ";
$result = $conn->query($sql);
$trainer=$result->fetch_assoc();

?>

<!DOCTYPE html>
<html lang="en">

<head>
  
    <title>Chazzen Fitness</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="images/favicon.png">
    <!-- Bootstrap Core CSS -->
    <link href="bower_components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="bower_components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>

<?php

include 'includes/header.php';
?>   
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-12">
                        <h4 class="page-title">Welcome to chazzen Fitness</h4>
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                <div class="row">
                    <div class="col-md-12 col-lg-12 col-sm-12">
                        <div class="white-box">
                            <div class="row row-in">
                                <div class="col-lg-3 col-sm-6">
                                    <div class="col-in text-center">
                                        <h5 class="text-danger">Total Video</h5>
                                        <h3 class="counter"><?php echo "$videos";  ?></h3>
                                    </div>
                                </div>
                                <div class="col-lg-3 col-sm-6">
                                    <div class="col-in text-center b-r-none">
                                        <h5 class="text-muted text-warning">Total student</h5>
                                        <h3 class="counter"><?php echo "$student";  ?></h3>
                                    </div>
                                </div>
                                 <div class="col-lg-3 col-sm-6">
                                    <div class="col-in text-center b-r-none">
                                        <h5 class="text-muted text-warning">Approvel Requests</h5>
                                        <h3 class="counter"><?php echo "$request";  ?></h3>
                                    </div>
                                </div>
                               <!--  <div class="col-lg-3 col-sm-6">
                                    <div class="col-in text-center">
                                        <h5 class="text-muted text-purple">total earned</h5>
                                        <h3 class="counter"><?php //echo $trainer['earned'];  ?></h3>
                                    </div>
                                </div> -->
                              
                            </div>
                           
                        </div>
                    </div>
                </div>
        <!-- /#page-wrapper -->
        <footer class="footer text-center" style="bottom: 0px"> 2021 &copy; Chazzen Fitness <a
                href="https://www.chazzenfitness.com/">chazzenfitness.com</a> </footer>
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>
    <!--Nice scroll JavaScript -->
    <script src="js/jquery.nicescroll.js"></script>
    <!--Morris JavaScript -->
    <script src="bower_components/raphael/raphael-min.js"></script>
    <script src="bower_components/morrisjs/morris.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/myadmin.js"></script>
    <script src="js/dashboard1.js"></script>
</body>

</html>